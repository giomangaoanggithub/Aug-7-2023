<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checking...</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="../official/css/index.css">

</head>

<body>
    <div id="show-loading"><img src="imgs/loading.gif" alt=""></div>
</body>
<script>
// if (window.location.href.includes("localhost") == false) {
//     window.location = window.location + "projects/a_product/official/pages/page_register_login.php";
// }
window.location = window.location + "pages/page_register_login.php";
</script>

</html>