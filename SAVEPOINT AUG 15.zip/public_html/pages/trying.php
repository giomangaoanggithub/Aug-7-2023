<?php

for($i = 0; $i < 8; $i++){
    echo ((100 / 7) * $i)."<br>";
}


?>