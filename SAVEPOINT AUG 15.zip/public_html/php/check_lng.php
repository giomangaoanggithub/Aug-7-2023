<?php
echo "REFERENCES:<br>";
echo strlen(file_get_contents("demo/demoman/mapping/REFERENCE1.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/mapping/REFERENCE2.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/mapping/REFERENCE3.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/mapping/REFERENCE4.txt"))."<br>";
echo "RAW REFERENCES:<br>";
echo strlen(file_get_contents("demo/demoman/all/RAW_REFERENCE1.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/all/RAW_REFERENCE2.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/all/RAW_REFERENCE3.txt"))."<br>";
echo strlen(file_get_contents("demo/demoman/all/RAW_REFERENCE4.txt"))."<br>";



?>