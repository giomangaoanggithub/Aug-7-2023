<?php
$dbname = "id20038880_essay_speed_checker_db";
$servername = "localhost";
$username = "id20038880_gio_mangaoang";
$password = "5Z%xrN{&YU$8zF*m";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  // echo "Connected successfully<br><br>";
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage().'<br><br>';
}
?>