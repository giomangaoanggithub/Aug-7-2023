<?php

date_default_timezone_set("Asia/Manila");

session_start();

$email = $_SESSION["teacher_account"];
$file_content = $_POST["references"];
$track = str_replace(" ","_",str_replace(":", " ", str_replace("/", " ", date("Y/m/d h:i:s:a"))));
$filename = "../../user_files/$email";

if (file_exists($filename)) {
    $filename = "../../user_files/$email/".$email."_".$track.".txt";
    $txt = str_replace("'"," ",str_replace('"',' ',$file_content));
    file_put_contents($filename, $txt);
}
else {
    mkdir("../../user_files/$email");
    $filename = "../../user_files/$email/".$email."_".$track.".txt";
    $txt = str_replace("'"," ",str_replace('"',' ',$file_content));
    file_put_contents($filename, $txt);
}



/* Choose where to save the uploaded file */

echo "YOUR REFERENCE IS READY!";


?>