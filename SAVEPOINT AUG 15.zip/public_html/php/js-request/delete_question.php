<?php
include '../mysql/db_connection.php';

$question = $_POST["question_id"];

try {
  // sql to delete a record
  $sql = "DELETE FROM questions WHERE question_id=$question";

  // use exec() because no results are returned
  $conn->exec($sql);
  echo "Question deleted successfully";
} catch(PDOException $e) {
  echo $sql . "<br>" . $e->getMessage();
}

$conn = null;
?>