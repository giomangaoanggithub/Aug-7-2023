<?php

session_start();

echo $_SESSION["loading_percentage"];

?>