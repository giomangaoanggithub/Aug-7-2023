<?php
session_start();

$_SESSION["student_account"] = "samplestudent_@email.com";

$_SESSION["teacher_account"] = "sampleteacher_@email.com";

?>